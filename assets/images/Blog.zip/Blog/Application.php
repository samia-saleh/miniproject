<?php

class Application
{
    public static $name = "My Blog";

    public static $blogName = "Clean Blog";

    public static $blogDescription = "A Blog Theme by Start Bootstrap";
}